
import React from 'react'

const Footer = () => {
  return (
    <div className="footer">
      {/* <span className="text-footer"> All Right reserved 2022 @LuluGide</span> */}
    </div>
  )
}

export default Footer


