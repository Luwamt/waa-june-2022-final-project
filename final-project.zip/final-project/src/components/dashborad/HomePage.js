import React from 'react'
import { useNavigate } from 'react-router';

const HomePage=()=>{

    const navigate = useNavigate();

    const onClick =()=>{
  navigate('/home/signin');
    }
    const onClickedContact=()=>{
      navigate("/home/contactUs")
    }

    return(

        <div className='home'>
{/* <h2>Alumni Management Portal</h2> */}
<p className='text' >Welcome to Alumni  Management Portal</p>
       <div id='btn'>

<button type="submit" className="btn btn-secondary" onClick={()=>{onClick()}}>Sign in</button>
</div>
<br/><br/>
<img src='https://th.bing.com/th/id/OIP.FQ9HfqcPNtt6xW1Q0aByogHaFj?w=197&h=180&c=7&r=0&o=5&dpr=2.5&pid=1.7' alt='miuImage' />
<img src='https://th.bing.com/th/id/OIP.FQ9HfqcPNtt6xW1Q0aByogHaFj?w=197&h=180&c=7&r=0&o=5&dpr=2.5&pid=1.7' alt='miuImage' />
<img src='https://th.bing.com/th/id/OIP.FQ9HfqcPNtt6xW1Q0aByogHaFj?w=197&h=180&c=7&r=0&o=5&dpr=2.5&pid=1.7' alt='miuImage' />
<div id='btn'>
<button type="submit" className="btn btn-secondary" onClick={()=>{onClickedContact()}}>Contact Us</button>

        </div>
        </div> 
    )
}
export default HomePage