import React from 'react'


const Profile =()=>{
    return(
<div>
    name profile
</div>

    )
}
export default Profile