import React from 'react'

const StudentProfile = () => {
  return (
    <div>StudentProfile

<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
  </div>
  <div class="custom-file">
    <input type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01"></input>
    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
  </div>
</div>

    </div>
  )
}

export default StudentProfile