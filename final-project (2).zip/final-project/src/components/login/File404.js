import React from 'react'

const File404 = () => {
  return (
    <div className='text'>
         404
        Page Not Find
    </div>
  )
}

export default File404